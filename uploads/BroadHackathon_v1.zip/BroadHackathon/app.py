from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# In-memory storage for posts (for simplicity)
posts = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        # For simplicity, we're not handling file uploads in this proof of concept
        post = {'title': title, 'description': description}
        posts.append(post)
        return redirect(url_for('posts_view'))
    return render_template('upload.html')

@app.route('/posts')
def posts_view():
    return render_template('posts.html', posts=posts)

if __name__ == '__main__':
    app.run(debug=True, port=5001)


#In PowerShell, run the following: 
# cd "C:\Users\ngoble\Documents\Python Scripts\BroadHackathon"
# .\.venv\Scripts\Activate.ps1
# python app.py
#Navigate to http://127.0.0.1:5001 to see your website in action.

#OR, in cmd run the following: # Navigate to the project directory
# cd "C:\Users\ngoble\Documents\Python Scripts\BroadHackathon"

# Activate the virtual environment
# .\.venv\Scripts\activate

# Run the Flask application
# python app.py

#Go to http://127.0.0.1:5001 in browser